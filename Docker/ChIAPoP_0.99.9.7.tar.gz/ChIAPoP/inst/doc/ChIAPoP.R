## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----simple_usage, eval=FALSE, include=FALSE-----------------------------
#  library('ChIAPoP');
#  pop.pipeline(fastq.1="/data_dir/read_1.fq",
#  	     fastq.2="/data_dir/read_2.fq",
#  	     bowtie.index="/data_dir/hg19");

## ----full_usage, eval=FALSE----------------------------------------------
#  pop.pipeline(fastq.1="/data_dir/read_1.fq",
#               fastq.2="/data_dir/read_2.fq",
#               bowtie.index="/data_dir/hg38",
#               bowtie.path="/tool_dir/bowtie",
#               macs2.path="/tool_dir/macs2",
#               gsize = "hs", chr.include = "all",
#               ref.genome = "hg38");
#  

## ----example, echo=FALSE, warning=FALSE----------------------------------
library(knitr)
#library(kableExtra)
results<-read.table(file="results_file_example.txt", header=TRUE);
print(results)
#results %>%
#  kable("html") %>%
#  kable_styling(bootstrap_options = c("striped", "hover", "condensed"))

## ----parameter_initial, eval=FALSE---------------------------------------
#  # Step 1: assigning parameter values
#  library('ChIAPoP')
#  fastq.1<-"/data_dir/read_1.fq"
#  fastq.2<-"/data_dir/read_2.fq"
#  bowtie.index<-"/data_dir/hg19"
#  bowtie.path<-"/tool_dir/bowtie"
#  macs2.path<-"/tool_dir/macs2"
#  gsize <- "hs"
#  chr.include <- "all"
#  ref.genome <- "hg19"

## ----linker_trimming, eval=FALSE-----------------------------------------
#  # Step 2: trimming linkers
#    trim.linkers(fastq.1,fastq.2)

## ----read_alignment, eval=FALSE------------------------------------------
#  # step 3 aligning four fastq read files in parallel by bowtie
#  fastq_files<-c("regular_1.fastq","regular_2.fastq",
#                 "chimeric_1.fastq","chimeric_2.fastq")
#  align_reads(fastq_files,bowtie.index,bowtie.path);
#  

## ----reads_filtering, eval=FALSE-----------------------------------------
#    # step 4 processing sam files
#    process.sam("regular_1.sam","regular_2.sam")
#    process.sam("chimeric_1.sam","chimeric_2.sam",PET.strand.info=FALSE)

## ----peak_calling, eval=FALSE--------------------------------------------
#    #step 5: calling peaks
#    call.peaks(macs2.path,c("regular_1_processed.sam",
#                        "regular_2_processed.sam",
#                        "chimeric_1_processed.sam",
#                        "chimeric_2_processed.sam"),
#               gsize=gsize,chr.include=chr.include)

## ----count_interaction, eval=FALSE---------------------------------------
#    # step 6 count number of interactions ...
#    count.interactions("regular_1_processed.sam","regular_2_processed.sam",
#                       "chimeric_1_processed.sam","chimeric_2_processed.sam",
#                       "macs2_peaks.narrowPeak",
#                       "regular_count.txt",
#                       "chimeric_count.txt",
#                       "anchor_info.txt",
#                       "PET_distance_strand.txt",
#                       ref.genome)
#  

## ----test_significance, eval=FALSE---------------------------------------
#    # step 7 testing for interactions
#    pop.test("regular_count.txt",
#             "chimeric_count.txt",
#             "anchor_info.txt",
#             "result.txt",
#             ref.genome=ref.genome)
#  

## ----test_example, eval=FALSE--------------------------------------------
#  #a test example
#  regular.count.file<-system.file("extdata", "regular_count.txt", package = "ChIAPoP")
#  chimeric.count.file<-system.file("extdata", "chimeric_count.txt", package = "ChIAPoP")
#  anchor.info.file<-system.file("extdata", "anchor_info.txt", package = "ChIAPoP")
#  results<-pop.test(regular.count.file,chimeric.count.file,anchor.info.file,"results.txt")
#  head(results)

