#' @importFrom graphics abline barplot legend lines plot points
NULL
#' @importFrom stats aggregate binomial coef complete.cases dpois ecdf glm optim p.adjust phyper poisson ppois predict quantile start
NULL
#' @importFrom utils adist head read.delim write.table
NULL
#' @importFrom grDevices dev.off pdf
NULL
#' @importFrom ShortRead FastqStreamer yield id sread
NULL
#' @import GenomeInfoDb
NULL
#' @importFrom GenomicAlignments cigarWidthAlongReferenceSpace
#' @import gplots
#' @import matrixStats
#' @importFrom parallel parLapply clusterExport makeCluster clusterApply
NULL


#' pop.pipeline
#'
#' The POP pipeline to run the full analysis of a ChIA-PET dataset
#' @param fastq.1 the fastq file of the first reads of paired-end data
#' @param fastq.2 the fastq file of the second reads of paired-end data
#' @param bowtie.index the bowtie index file of the reference genome. For example, the index filename is /idxDIR/referenceIndex if the index is built with the command 'bowtie-build referencGenome.fa /idxDIR/referenceIndex'
#' @param bowtie.path the full bowtie command path, e.g. /tools/bin/bowtie. The default assumes that bowtie is in the system search paths
#' @param macs2.path the full path of MacS2 command, e.g., /tools/bin/macs2. The default asumes that macs2 is in the system search paths
#' @param gsize the size of reference genome of which ChIA-PET data are derived from. It is can be either number of bases or a known abbreviation of the species of genome reference, e.g, "hs" for the human genome, "mm" for the mouse genome (default: "hs", the size of the human genome).
#' @param chr.include the chromosomes included for peak calling analysis (default: "all", all chromosomes are included)
#' @param ref.genome  the reference genome name (default: hg19). It is required for calculation distance between two interaction anchor sites. The reference name should be accepted by the GenomeInfoDb package. The current supported genome reference names are:   hg38,  hg19,  hg18,  panTro4,  panTro3,  panTro2,  bosTau8,  bosTau7,  bosTau6, canFam3,  canFam2,  canFam1,  musFur1,  mm10,  mm9,  mm8,  susScr3,  susScr2,  rn6,  rheMac3, rheMac2, galGal4, galGal3, gasAcu1, danRer7, apiMel2, dm6, dm3, ce10, ce6, ce4, ce2, sacCer3, sacCer2.
#' @return NULL. The output from this pipeline includes the main result file \code{result.txt}. The result file contains the following eight fields: chr1, start1,end1, chr2, start2, end2, count, p.value, p.fdr. p.value and p.fdr are p-value and false discovery rate (Benjamini-Hochberg method) of observing a read-pair count of an interaction.  The pipeline also generates two model fitting plot files: 1) \code{truncated_poisson_fit.pdf} for truncated Poisson model fitting, and 2) \code{logistic_regression_fit.pdf} for logistic regression fitting.
#' @examples
#' #this example takes two fastq files (read1 and read2) from a human ChIA-PET data,
#' #and uses the default the human genome hg19 to run the full analysis.
#' #This example assumes that both MacS2 and Bowite tools are in system search directories.
#' \dontrun{
#' # fastq file of the first reads
#' fq1<-"input_fastq_read1.fastq";
#' # fastq file of the second reads
#' fq2<-"input_fastq_read2.fastq";
#' #run the full analysis
#' pop.pipeline(fq1,fq2)
#' }
#' @export
pop.pipeline<-function(fastq.1,fastq.2,
                       bowtie.index, bowtie.path="bowtie",
                       macs2.path="macs2",gsize="hs",chr.include="all",
                       ref.genome="hg19"){
  # step 1
  print("Step 1: trimming linkers ...")
  trim.linkers(fastq.1,fastq.2)
  print("Step 1 is done!")

  # step 2
  print("Step 2: aligning reads in parallel")
#  library("parallel");
  fqlst<-c("regular_1.fastq","regular_2.fastq","chimeric_1.fastq","chimeric_2.fastq")
  ncores<-length(fqlst);
  cl <- makeCluster(mc <- getOption("cl.cores", ncores));
  clusterExport(cl=cl, varlist=c("bowtie.path","bowtie.index"), envir=environment());
#  parLapply(cl, fqlst, bowtie.alignment, bowtie.path,bowtie.index);
  clusterApply(cl, fqlst, bowtie.alignment, bowtie.path=bowtie.path,bowtie.index=bowtie.index);
  print("Step 2 is done!")

  # step 2
#  print("Step 2: aligning reads ...")
#  if(.Platform$OS.type=="windows"){
#    bowtie.alignment("regular_1.fastq",bowtie.path,bowtie.index)
#    bowtie.alignment("regular_2.fastq", bowtie.path,bowtie.index)
#    bowtie.alignment("chimeric_1.fastq", bowtie.path,bowtie.index)
#    bowtie.alignment("chimeric_2.fastq", bowtie.path,bowtie.index)
#  }
#  else{
#    library("parallel");
#    print ("here");
#    j1 <- mcparallel(bowtie.alignment("regular_1.fastq",bowtie.path,bowtie.index))
#    j2 <- mcparallel(bowtie.alignment("regular_2.fastq", bowtie.path,bowtie.index))
#    j3 <- mcparallel(bowtie.alignment("chimeric_1.fastq", bowtie.path,bowtie.index))
#    j4 <- mcparallel(bowtie.alignment("chimeric_2.fastq", bowtie.path,bowtie.index))
#    mccollect(list(j1, j2, j3, j4));
#  }
#  print("Step 2 is done!")

  # step 3
  print("Step 3: processing sam files ...")
  process.sam("regular_1.sam","regular_2.sam")
  process.sam("chimeric_1.sam","chimeric_2.sam",PET.strand.info=FALSE)
  print("Step 3 is done!")

  # step 4
  print("Step 4: calling peaks ...")
  call.peaks(macs2.path,c("regular_1_processed.sam","regular_2_processed.sam","chimeric_1_processed.sam","chimeric_2_processed.sam"),gsize=gsize,chr.include=chr.include)
  print("Step 4 is done!")

  # step 5
  print("Step 5: creating count tables ...")
  count.interactions("regular_1_processed.sam","regular_2_processed.sam","chimeric_1_processed.sam","chimeric_2_processed.sam","macs2_peaks.narrowPeak",
                     "regular_count.txt","chimeric_count.txt","anchor_info.txt",
                     distance.strand.file="PET_distance_strand.txt",ref.genome=ref.genome)
  print("Step 5 is done!")

  # step 6
  print("Step 6: testing for interactions ...")
  pop.test("regular_count.txt","chimeric_count.txt","anchor_info.txt","result.txt",ref.genome=ref.genome)
  print("Step 6 is done!")
}
