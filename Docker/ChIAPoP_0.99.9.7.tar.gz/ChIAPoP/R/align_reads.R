

##### align with bowtie
#################################################################################################################
##### -v 0 (mismatch not allowed); -m 1 (multiple possible alignment not allowed); -k 1 (report only the first alignment)
#####  with -m 1, no need to specify -k. Furthermore, -k 1 is the default.
#################################################################################################################
##### threads should be 1. otherwise, the order of the output will not be the same as the order of the input.
##### If use more than 1 thread, then should use sort -t "." -k 1,2 inputfile to sort the output sam file
#################################################################################################################
##### removed --chunkmbs 500 because it is only useful for --best mode.
#' bowtie.alignment
#'
#' this function performs bowtie reads alignment for each fastq file in the single-end read alignment mode. The alignment setting neither allows mismatch (-v 0) nor allows multiple alignment (-m 1).
#``
#' @param fastq the input fastq file
#' @param bowtie.path the full bowtie command path, e.g. /usr/bin/bowtie.
#' @param bowtie.index the filename of bowtie index of reference genome. For example, the index filename is /idxDIR/referenceIndex if the index is built with the command 'bowtie-build referencGenome.fa /idxDIR/referenceIndex'.
#' @param output the output same file name. The default output sam file is the same fastq filename prefix but with sam filename extension. For example, if the input fastq file  is reads_1.fastq, then then output sam file is reads_1.sam.
#' @param remove.fastq a logical indicator to specify if delete the input fastq file after alignment (default TRUE).
#' @export
bowtie.alignment<-function(fastq,bowtie.path,bowtie.index,output=gsub(".fastq$",".sam",fastq),remove.fastq=TRUE){
  ##### find the score type (bowtie aligner needs this) of fastq file.
  ##### this function requires package "ShortRead"
  if(system(paste(bowtie.path, "--version", sep=" "))>0){
	  print("Error: bowtie is either not installed or not in system search paths!");
	  stop("Please install bowtie or specify the correct installation path with the bowtie.path parameter.")
  }
  if(!file.exists(fastq)){
	  stop(paste("fastq file", fastq, "does not exist"));
  }
  find.score.type<-function(fl){
    ## open input stream
    stream<-ShortRead::FastqStreamer(fl);  on.exit(close(stream))

    fq<-ShortRead::yield(stream)

    unlist.quality<-unlist(Biostrings::quality(Biostrings::quality(fq)))
    min.ascii<-min(utf8ToInt(as.character(unlist.quality)));

    # check score
    if (min.ascii<59){
      print("Score type detected: Sanger/Illumina 1.8")
      score.type<-"--phred33-quals"
    }
    else if (min.ascii<64){
      print("Score type detected: Solexa")
      score.type<-"--solexa-quals"
    }
    else{
      print("Score type detected: Illumina 1.3-1.8")
      score.type<-"--phred64-quals"
    }

    # return the score
    return(score.type)
  }
  # make sure only one threads used to ensure read order
  threads<-1;

  #make sure that output file end with .sam extension
  if(!grepl(".sam$",output)) { output<-sub(".fq$",".sam",fastq);}
  if(!grepl(".sam$",output)) { output<-sub(".\\w+$",".sam",fastq);}


#    if(!suppressMessages(suppressWarnings(require("ShortRead")))){
#    stop("Package ShortRead is not installed!")
#  }
#  else{
#    print("Package ShortRead has been loaded.")
#  }

  # detect quality score type (bowtie needs this)
  score.type<-find.score.type(fastq)

  # form bowtie command
  bowtie.option<-paste("-S -v 0 -k 1 --sam-nohead --mapq 40 -m 1 --threads",threads,score.type,sep=" ")
  bowtie.command<-paste(bowtie.path,bowtie.option,bowtie.index,fastq,output,sep=" ")

  # print bowtie command
  print (bowtie.command)

  # execute command
  system(bowtie.command)

  # remove .fastq file when needed
  if (remove.fastq) {
    invisible(file.remove(fastq))
  }
}

#' align_reads
#'
#' Parallel alignment of individual fastq files by bowtie read alignment tool \url{http://bowtie-bio.sourceforge.net/index.shtml}
#' @param fastqFiles a vector of fastq files to be aligned with bowtie
#' @param bowtie.index the filename of bowtie index of reference genome. For example, the index filename is /idxDIR/referenceIndex if the index is built with the command 'bowtie-build referencGenome.fa /idxDIR/referenceIndex'.
#' @param bowtie.path the full bowtie command path, e.g. /tool_dir/bowtie (default: bowtie). The default assumes that the tool is in a system search path, e.g., /usr/bin/bowtie.
#' @export
#' @examples
#' \dontrun{
#' # input fastq files
#' fqList<-c("regular_1.fastq","regular_2.fastq","chimeric_1.fastq","chimeric_2.fastq");
#' # the prefix file name of bowtie index file of the hg19 reference genome
#' bowtieIdx<-"/genomesDir/hg19"
#' bowtieCmd<-"bowtie"
#' # if bowtie is not in system search paths, specify bowtie tool path,
#' # e.g., bowtieCmd<-"/toolDir/bowtie"
#' # run bowtie alignment of all input fastq files in parallel
#' align_reads(fqList,bowtieIdx,bowtieCmd);
#'
#' }
align_reads<-function(fastqFiles,bowtie.index, bowtie.path="bowtie"){
  print("align reads by bowtie in parallel");
  if(system(paste(bowtie.path, "--version", sep=" "))>0){
	  print("Error: bowtie is either not installed or not in system search paths!");
	  stop("Please install bowtie or specify the correct installation path with the bowtie.path parameter.");
  }
  ncores<-length(fastqFiles);
  cl <- makeCluster(mc <- getOption("cl.cores", ncores));
  clusterExport(cl=cl, varlist=c("bowtie.path","bowtie.index"), envir=environment());
  clusterApply(cl, fastqFiles, bowtie.alignment, bowtie.path=bowtie.path,bowtie.index=bowtie.index, remove.fastq=FALSE);
  print("done alignment!")
}
