find.linkers<-function(linker,sequence,tag.end.ub,mh){
  matches<-Biostrings::vmatchPattern(linker,sequence,fixed=TRUE,max.mismatch=mh)
  start.pos<-Biostrings::startIndex(matches)

  index<-(S4Vectors::elementNROWS(matches)==1L)
  index[index]<-(unlist(start.pos[index],use.names=FALSE)>tag.end.ub)

  return(list(start.pos=start.pos,index=index))
}

choose.linker.type<-function(index.A,index.B,start.A,start.B){
  index.both<-(index.A & index.B)

  temp<-(unlist(start.A[index.both],use.names=FALSE)>unlist(start.B[index.both],use.names=FALSE))

  index.A.new<-index.A; index.A.new[index.both]<-temp;
  index.B.new<-index.B; index.B.new[index.both]<-(!temp);

  return(list(A=index.A.new,B=index.B.new))
}

select.reads<-function(fq.1,fq.2,index,start.1,start.2){
  fq.1.part<-IRanges::narrow(fq.1[index],1,unlist(start.1[index],use.names=FALSE)-1)
  fq.2.part<-IRanges::narrow(fq.2[index],1,unlist(start.2[index],use.names=FALSE)-1)

  return(list(fq.1.part=fq.1.part,fq.2.part=fq.2.part))
}

##### trim linkers
##### this function requires package "ShortRead"
#' trim.linkers
#'
#' This function trims linker sequences in sequencing reads, and separates chimeric read pairs from non-chimeric read pairs based on their linker types.
#' The chimeric read pairs are saved to the new chmmeric fastq files designed by \code{destination.chimeric}, and non-chimeric read pairs are saved to the new
#' fastq files designed by \code{destination.regular}.
#'
#' @param fl.1 the fastq file of the first reads
#' @param fl.2 the fastq file of the second reads
#' @param linkers a character vector with a pair of linker sequences. The default linkers are \code{GTTGGATAAGATATC} and \code{GTTGGAATGTATATC}
#' @param destination.regular two new fastq files of non-chimeric first and second reads, respectively. The default is \code{c("regular_1.fastq","regular_2.fastq")}
#' @param destination.chimeric two new fastq files of chimeric first and second reads, respectively. The default is \code{c("chimeric_1.fastq","chimeric_2.fastq")}
#' @param tag.end.ub the minimum length of (non-linker) sequences (default 18). The reads with non-linker sequence shorter this length will be removed from further analysis
#' @param mh the maximum number of mismatches allowed in searching for linker sequences.
#' @examples
#' fq1<-system.file("extdata", "toy_fastq_1.fastq", package = "ChIAPoP")
#' fq2<-system.file("extdata", "toy_fastq_2.fastq", package = "ChIAPoP")
#' outputDIR<-tempdir();
#' regularReads<-paste(outputDIR,c("regular_1.fastq","regular_2.fastq"),sep="/");
#' chimericReads<-paste(outputDIR,c("chimeric_1.fastq","chimeric_2.fastq"),sep="/");
#' trim.linkers(fq1,fq2,destination.regular=regularReads,destination.chimeric=chimericReads);
#' ##remove output example files
#' #file.remove(c(regularReads,chimericReads));
#' @export
trim.linkers<-function(fl.1,fl.2,
                       linkers=c("GTTGGATAAGATATC","GTTGGAATGTATATC"),
                       destination.regular=c("regular_1.fastq","regular_2.fastq"),destination.chimeric=c("chimeric_1.fastq","chimeric_2.fastq"),
                       tag.end.ub=18,mh=1){
#  if(!suppressMessages(suppressWarnings(require("ShortRead")))){
#    stop("Package ShortRead is not installed!")
#  }
#  else{
#    print("Package ShortRead has been loaded.")
#  }
  #remove existing fastq files
  if(file.exists(destination.regular[1])){
    invisible(file.remove(destination.regular));
    invisible(file.remove(destination.chimeric));
  }

  # get linkers
  linker.A<-linkers[1]; linker.B<-linkers[2];

  ## open input stream
  stream.1<-ShortRead::FastqStreamer(fl.1); on.exit(close(stream.1))
  stream.2<-ShortRead::FastqStreamer(fl.2); on.exit(close(stream.2),add=TRUE)

  n.AA<-0; n.BB<-0; n.AB<-0; n.BA<-0; n<-0
  repeat {
    ## input chunk
    fq.1<-ShortRead::yield(stream.1); fq.2<-ShortRead::yield(stream.2);
    if (length(fq.1)==0){
      break
    }

    ## trim linkers
    # check linker type for each reads
    temp<-find.linkers(linker.A,sread(fq.1),tag.end.ub=tag.end.ub,mh=mh); idx.A.1<-temp$index; start.A.1<-temp$start.pos;
    temp<-find.linkers(linker.B,sread(fq.1),tag.end.ub=tag.end.ub,mh=mh); idx.B.1<-temp$index; start.B.1<-temp$start.pos;
    temp<-find.linkers(linker.A,sread(fq.2),tag.end.ub=tag.end.ub,mh=mh); idx.A.2<-temp$index; start.A.2<-temp$start.pos;
    temp<-find.linkers(linker.B,sread(fq.2),tag.end.ub=tag.end.ub,mh=mh); idx.B.2<-temp$index; start.B.2<-temp$start.pos;

    # assign linker type for those with both linker types (which linker is closer to the end?)
    temp<-choose.linker.type(idx.A.1,idx.B.1,start.A.1,start.B.1); idx.A.1<-temp$A; idx.B.1<-temp$B;
    temp<-choose.linker.type(idx.A.2,idx.B.2,start.A.2,start.B.2); idx.A.2<-temp$A; idx.B.2<-temp$B;

    # trim linkers and separate reads into different combinations of linker types
    temp<-select.reads(fq.1,fq.2,idx.A.1 & idx.A.2,start.A.1,start.A.2); fq.1.AA<-temp$fq.1.part; fq.2.AA<-temp$fq.2.part;
    temp<-select.reads(fq.1,fq.2,idx.B.1 & idx.B.2,start.B.1,start.B.2); fq.1.BB<-temp$fq.1.part; fq.2.BB<-temp$fq.2.part;
    temp<-select.reads(fq.1,fq.2,idx.A.1 & idx.B.2,start.A.1,start.B.2); fq.1.AB<-temp$fq.1.part; fq.2.AB<-temp$fq.2.part;
    temp<-select.reads(fq.1,fq.2,idx.B.1 & idx.A.2,start.B.1,start.A.2); fq.1.BA<-temp$fq.1.part; fq.2.BA<-temp$fq.2.part;

    ## append to destination
    ShortRead::writeFastq(fq.1.AA,destination.regular[1],mode="a",compress=FALSE); ShortRead::writeFastq(fq.2.AA,destination.regular[2],mode="a",compress=FALSE);
    ShortRead::writeFastq(fq.1.BB,destination.regular[1],mode="a",compress=FALSE); ShortRead::writeFastq(fq.2.BB,destination.regular[2],mode="a",compress=FALSE);

    ShortRead::writeFastq(fq.1.AB,destination.chimeric[1],mode="a",compress=FALSE); ShortRead::writeFastq(fq.2.AB,destination.chimeric[2],mode="a",compress=FALSE);
    ShortRead::writeFastq(fq.1.BA,destination.chimeric[1],mode="a",compress=FALSE); ShortRead::writeFastq(fq.2.BA,destination.chimeric[2],mode="a",compress=FALSE);

    ## count pairs
    n.AA<-n.AA+sum(idx.A.1 & idx.A.2); n.BB<-n.BB+sum(idx.B.1 & idx.B.2);
    n.AB<-n.AB+sum(idx.A.1 & idx.B.2); n.BA<-n.BA+sum(idx.B.1 & idx.A.2);
    n<-n+length(fq.1);

  }

  # print summary of pairs
  print(paste("Total number of pairs: ",n,sep=""))
  print(paste("Number of pairs with AA linkers: ",n.AA," (",round(n.AA/n*100,2),"%)",sep="")); print(paste("Number of pairs with BB linkers: ",n.BB," (",round(n.BB/n*100,2),"%)",sep=""));
  print(paste("Number of pairs with AB linkers: ",n.AB," (",round(n.AB/n*100,2),"%)",sep="")); print(paste("Number of pairs with BA linkers: ",n.BA," (",round(n.BA/n*100,2),"%)",sep=""));
  ## print filenames
  print("The new fastq files of regular read pairs with AA or BB linkers")
  print(paste(destination.regular, sep=";", collapse = ", "));
  print("The new fastq files of chimeric read pairs with AB or BA linkers")
  print(paste(destination.chimeric, sep=";", collapse = ", "));
}

