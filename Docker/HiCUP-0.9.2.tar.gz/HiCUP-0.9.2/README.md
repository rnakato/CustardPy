HiCUP (Hi-C User Pipeline)
--------------------------

**HiCUP is a bioinformatics pipeline for processing Hi-C data.**

[HiCUP homepage](http://www.bioinformatics.babraham.ac.uk/projects/hicup)

[HiCUP Documentation](https://stevenwingett.github.io/HiCUP/)

What to contribute to the HiCUP codebase?  If so, please push updates via GitHub to the "development" branch.

[Contact the software author to discuss the software, report bugs or suggest enhancements](https://github.com/StevenWingett/HiCUP/issues)
